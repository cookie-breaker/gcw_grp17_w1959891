// Array of Questions with answers
const quizData = [
    {
        question: "What is the highest individual score by a batsman in Test cricket?",
        a: "375",
        b: "400",
        c: "501",
        d: "600",
        correct: "c",
    },
    {
        question: "Who is the all-time leading goal scorer in men's international football?",
        a: " Lionel Messi",
        b: "Cristiano Ronaldo",
        c: "Pelé",
        d: "Miroslav Klose",
        correct: "b",
    },
    {
        question: "How many players are on a volleyball team?",
        a: "12",
        b: "6",
        c: "8",
        d: "10",
        correct: "b",
    },
    {
        question: "Which stroke is not used in the individual medley event?",
        a: "Backstroke",
        b: "Freestyle",
        c: "Breaststroke",
        d: "Butterfly",
        correct: "c",
    },
    {
        question: "Which country has won the most ICC Cricket World Cup titles?",
        a: "South Africa",
        b: "Srilanka",
        c: "India",
        d: "Australia",
        correct: "d",
    },
    {
        question: "Which country won the 2018 FIFA World Cup?",
        a: "Spain",
        b: "Germany",
        c: "France",
        d: "Brazil",
        correct: "c",
    },
    {
        question: "Which country has won the most Olympic gold medals in volleyball?",
        a: "China",
        b: "United States",
        c: "Russia",
        d: "Brazil",
        correct: "d",
    },

    {
        question: "How many events are in the women's individual medley?",
        a: "1",
        b: "2",
        c: "3",
        d: "4",
        correct: "b",
    },

    {
        question: "Who has scored the most runs in international cricket?",
        a: "Ricky Ponting",
        b: "Sachin Tendulkar",
        c: "Virat Kohli",
        d: "Kumar Sangakkara",
        correct: "c",
    },
    {
        question: "Who won the 2021 UEFA Champions League?",
        a: "Real Madrid",
        b: "Chelsea",
        c: "Bayern Munich",
        d: "Manchester City",
        correct: "b",
    },
];

// Variables
const quiz= document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')
let currentQuiz = 0
let score = 0
const startTime = new Date();


loadQuiz()
// Loading quiz content from quizData array 
function loadQuiz() {  
    deselectAnswers()
    const currentQuizData = quizData[currentQuiz]
    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}

// Clearing previously selected answers from the current quiz question
function deselectAnswers() {
    answerEls.forEach(answerEl => answerEl.checked = false)
}

// retrieving the selected answer for the current quiz question
function getSelected() {
    let answer
    answerEls.forEach(answerEl => {
        if(answerEl.checked) {
            answer = answerEl.id
        }
    })
    return answer
}
// event listner for submit button
submitBtn.addEventListener('click', () => {
    const answer = getSelected()

    // checking if the user has selected any answer
    if(answer) {
        
        // score is incremented by 1 if the user's answer matches the correct answer
       if(answer === quizData[currentQuiz].correct) {
           score++
       }

       // currentQuiz is incremented by 1 to move to the next question in the array  
       currentQuiz++

       // checking if there're any more questions left in the quiz

       if(currentQuiz < quizData.length) {

           loadQuiz() // Loading next question

       } else {
        // if no more questions left displaying the summary of the quiz

           const endTime = new Date();  //getting the quiz ended time

           const timeDiff = endTime - startTime; //getting the time difference

          // calculating the name in minutes and seconds
           const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
           const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));

          //   saving grade of the quiz 
           var grade = calculateGrade();

           //Updating the quiz container HTML to show the user's score, time taken, and grade
           quiz.innerHTML = `
           </br>
           <h2> All Questions : 10</h2>
           <h2> Correct Questions : ${score} </h2>
           <h2>Time taken: ${minutes} minutes ${seconds} seconds</h2>
           </br>
           <h1>your grade : ${grade} </h1>
           </br>
           <button onclick="location.reload()">Reload</button>
           </br>
           `;

           quiz.style.backgroundColor = "burlywood";

           
       }
    }
})




// function to record the satarted time of the quiz
function startTimer() {
    startTime = new Date();
}




// calculating the grade of the user based on a if else conditions and returing the grade
function calculateGrade() {
    const percentage = (score / quizData.length) * 100;
    let grade;
    if (percentage >= 90) {
        grade = 'Excellent';
    } else if (percentage >= 70) {
        grade = 'Good';
    } else if (percentage >= 50) {
        grade = 'Average';
    } else if (percentage >= 30) {
        grade = 'Poor';
    } else {
        grade = 'Bad';
    }
    return grade;
}

